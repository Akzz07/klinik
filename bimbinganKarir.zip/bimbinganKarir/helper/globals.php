<?php
$BASE_URL = 'http://localhost/bimbinganKarir';
?>